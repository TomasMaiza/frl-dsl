module Main where

import AST
import Eval

main :: IO ()
main = putStrLn "Hello, Haskell!"
