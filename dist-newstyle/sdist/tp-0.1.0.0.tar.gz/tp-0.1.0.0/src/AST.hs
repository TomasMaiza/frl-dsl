module AST where

-- Identificadores de Variable
type Variable = String
type Nat = Int

-- Listas
data List = Nil 
          | Unit Nat
          | Cons Nat List Nat
          | Concat List List
          | Var Variable
          deriving (Show, Eq)

-- Funciones
data Fun
  = Repeat Fun List
  | LeftZero List
  | RightZero List
  | LeftDel List
  | RightDel List
  | LeftSucc List
  | RigthSucc List
  | MoveLeft List
  | MoveRight List
  | DupLeft List
  | DupRight List
  | Swap List
  | Comp Fun Fun List
  deriving (Show, Eq)

data Error = DomainErr | UndefVar deriving (Eq, Show)

type Trace = String
