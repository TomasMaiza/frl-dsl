module Eval
  ( evalFun
  , Env
  )
where

import           AST
import           Monads
import qualified Data.Map.Strict               as M
import           Data.Maybe
import           Prelude                 hiding ( fst
                                                , snd
                                                )
import           Data.Strict.Tuple
import           Control.Monad                  ( liftM
                                                , ap
                                                )

-- Entornos
type Env = M.Map Variable List

-- Entorno nulo
initEnv :: Env
initEnv = M.empty

-- Mónada estado
newtype State a = State { runState :: Env -> (a, Env) }

instance Monad State where
  return x = State (\s -> (x, s))
  m >>= f = State (\s -> let (v, s') = runState m s
                         in runState (f v) s')

-- Para calmar al GHC
instance Functor State where
  fmap = liftM

instance Applicative State where
  pure  = return
  (<*>) = ap

instance MonadState State where
  lookfor v = State (\s -> (lookfor' v s, s))
    where lookfor' v s = fromJust $ M.lookup v s
  update v i = State (\s -> ((), update' v i s)) where update' = M.insert


-- Evalua multiples pasos de un comando, hasta alcanzar un Skip
{-stepFun:: MonadState m => Fun -> m ()
stepFun Skip = return ()
stepFun c    = stepComm c >>= \c' -> stepCommStar c'-}

-- Evalua un programa en el estado nulo
{-eval :: Fun -> Env
eval p = snd (runState p initEnv)-}

--eval :: Fun -> Env

evalFun :: MonadState m => Fun -> m List
evalFun (LeftZero ls) = case ls of
                          Nil -> return (Unit 0)
                          Unit x -> return (Cons 0 Nil x)
